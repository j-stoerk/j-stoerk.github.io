CHARGEWISE AI - portable test build

Requires Python 3.11+ and uv (https://docs.astral.sh/uv/).
Extract the ZIP, open a terminal in that directory and run:

    uv run --locked python scripts/run_demo.py

Open http://127.0.0.1:8000/?demo=1. Stop with Ctrl+C.
The frontend is already built: Node.js is unnecessary for this package.
uv downloads locked Python dependencies on first use. No model weights,
inference API token or payment is needed for the local planning demo.

Click Load sample, then Start guided demo. Four vans, two plugs:
FCFS/EDF/LLF peak at 22 kW; optimized peak 8.89 kW; all energy targets met.
Capacity proof is available. Outage raises peak to 10 kW with all targets met.
These are synthetic, partial-period results, not measured fleet savings.

Edit inputs lets you resize the fleet and add/remove vehicles and chargers.
Change arrival/departure, battery capacity, initial/target SoC, energy,
individual charger kW, connectors, availability, site power, prices and tariffs.
Apply & recalculate validates and solves your configuration. The walkthrough
keeps your edits; only Load sample restores the fixture. Large lists paginate.
The interactive solver's 72-hour horizon and complexity budget still apply.

The assistant uses a clearly labelled local computed summary when no provider
is configured. This is NOT evidence of NVIDIA model execution on Nebius.
The separate recorded demonstration contains actual NVIDIA inference.

Optional private live mode (not needed for the planning demo):

    uv run --locked python scripts/run_live_demo.py --budget 0.05 --requests 12

Enter your own Token Factory key at the hidden prompt; it is not saved.
Open http://127.0.0.1:8017. Stop with Ctrl+C to discard the key.
Only the verified-price NVIDIA Lightning model is allowed. Reservations persist
in .cache/cloud-inference-budget.json across restarts; never reset/delete them.
The allowance is local to this installation, not an account-wide billing cap.
Never expose an enabled paid assistant to unauthenticated public traffic.

No physical charger is controlled. State is in memory and resets on restart.
Use one worker, and do not expose the local instance as a production service.

Source and full development setup:
https://github.com/j-stoerk/nebiusxnvidia_hackathon
Code/generated fixture: MIT. Dependency licences remain applicable.
BUILD_REVISION.txt records the source commit for this package.
